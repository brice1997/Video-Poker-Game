Alex Brice Horimbere

PP4
Computer science 1004


As you can see, I submitted late this assignment because it took me 
years to finish it. I have no background in programming, and that is 
one of the reasons these bugs exist in my code (I guess if I worked harder
I could fixed them, but I am really running out of time)

1. The game constructor that takes a command line does not work. I could not 
figure out how to take that hand and check it. In the method play(), I 
envisionned that when the game takes a command line, it would do this
(like an if statement), else(it doesn't take anything), it would do that. 
But I could not translate that into code. 

2. To test my code then, you can rely on the normal game. I print the deck and 
the hand, so you can see the hand you have and whether it accurately evaluates it.

3.I wished I could have fixed the first problem, but I truly did not have time. 


